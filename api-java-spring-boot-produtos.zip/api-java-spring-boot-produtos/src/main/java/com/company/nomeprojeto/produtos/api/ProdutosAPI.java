package com.company.nomeprojeto.produtos.api;

import com.company.nomeprojeto.produtos.DTO.ProdutoDTO;
import com.company.nomeprojeto.produtos.facade.ProdutosFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller // Definir para ser usada na Internet
@RequestMapping(value = "/produtos", produces = MediaType.APPLICATION_JSON_VALUE) // A API vai sempre devolver um JSON
public class ProdutosAPI {
    @Autowired // Pra fazer a Instância da outra classe
    private ProdutosFacade produtosFacade;

    @PostMapping
    @ResponseBody // Sempre tem que colocar essa notação para devolver um JSON
    public ProdutoDTO criar(@RequestBody ProdutoDTO produtoDTO){ // Esse método está recebendo um DTO no body do request, então tem que colocar a notação "RequestBody"
        return produtosFacade.criar(produtoDTO);
    }

    @PutMapping
    @ResponseBody
    public ProdutoDTO atualizar(@RequestBody ProdutoDTO produtoDTO){ // Esse método vai receber um parâmetro na URL mais atributos no body pra fazer a requisição
        return produtosFacade.atualizar(produtoDTO);
    }

    @GetMapping
    @ResponseBody
    public List<ProdutoDTO> getAll(){ // Retorna todos os registros
        return produtosFacade.getAll();
    }


    @GetMapping("/id/{produtoId}")
    @ResponseBody
    public ProdutoDTO getById(@PathVariable Long produtoId){ // Retorna o produto pelo ID
        return produtosFacade.getById(produtoId);
    }


    @GetMapping("/categoria/{produtoCategoria}")
    @ResponseBody
    public List<ProdutoDTO> getByCategoria(@PathVariable String produtoCategoria){ // Retorna o produto pela categoria
        return produtosFacade.getByCategoria(produtoCategoria);
    }

    @DeleteMapping("/{produtoId}")
    @ResponseBody // Pra retornar algo no resultado
    public String deletar(@PathVariable("produtoId") Long produtoId){
        return produtosFacade.delete(produtoId);
    }

}
