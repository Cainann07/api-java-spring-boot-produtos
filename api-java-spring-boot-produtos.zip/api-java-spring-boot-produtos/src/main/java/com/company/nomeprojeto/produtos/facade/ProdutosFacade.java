package com.company.nomeprojeto.produtos.facade;

import com.company.nomeprojeto.produtos.DTO.ProdutoDTO;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ProdutosFacade {
    private static final Map<Long, ProdutoDTO> produtos = new HashMap<>();

    public ProdutoDTO criar(ProdutoDTO produtoDTO){
        Long proximoId = produtos.keySet().size() + 1L;
        produtoDTO.setId(proximoId);
        produtos.put(proximoId, produtoDTO);
        return produtoDTO;

    }

    public ProdutoDTO atualizar(ProdutoDTO produtoDTO){
        Long produtoId = produtoDTO.getId();
        if (produtoId == null) {
            throw new IllegalArgumentException("ID do produto não pode ser nulo.");
        }

        ProdutoDTO produtoExistente = produtos.get(produtoId);

        if (produtoExistente == null){
            throw new IllegalArgumentException("Produto com ID " + produtoId + " não encontrado.");
        }

        produtoExistente.setNome(produtoDTO.getNome());
        produtoExistente.setPreco(produtoDTO.getPreco());
        produtoExistente.setCategoria(produtoDTO.getCategoria());

        produtos.put(produtoId, produtoExistente);
        return produtoDTO;
    }

    public ProdutoDTO getById(Long produtoId){
        return produtos.get(produtoId);
    }

    public List<ProdutoDTO> getAll(){
        return new ArrayList<>(produtos.values());
    }

    public List<ProdutoDTO> getByCategoria(String categoria){
        return produtos.values().stream().filter(p -> p.getCategoria().equalsIgnoreCase(categoria)).collect(Collectors.toList());
    }

    public String delete(Long produtoid){
        produtos.remove(produtoid);
        return "Requisição atendida e exclusão feita com sucesso.";
    }
}
